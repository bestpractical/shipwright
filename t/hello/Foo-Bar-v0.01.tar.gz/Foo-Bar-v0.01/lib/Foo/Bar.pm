package Foo::Bar;

use warnings;
use strict;
use Carp;

our $VERSION = '0.01';





1;

__END__

=head1 NAME

Foo::Bar - 


=head1 VERSION

This document describes Foo::Bar version 0.0.1


=head1 SYNOPSIS

    use Foo::Bar;

=head1 DESCRIPTION


=head1 INTERFACE



=head1 DEPENDENCIES


None.


=head1 INCOMPATIBILITIES

None reported.


=head1 BUGS AND LIMITATIONS

No bugs have been reported.

=head1 AUTHOR

sunnavy  C<< <sunnavy@bestpractical.com> >>


=head1 LICENCE AND COPYRIGHT

Copyright 2009 Best Practical Solutions.

This program is free software; you can redistribute it and/or modify it
under the same terms as Perl itself.

